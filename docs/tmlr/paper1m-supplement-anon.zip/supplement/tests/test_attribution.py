"""D8 attribution core (prereg d8-attribution-prereg-v0.1.md, commit a39f555).

These tests assert IDENTITIES, GATES, and STRUCTURAL ZEROS only — no sign or
size of any Δ at a non-null cell is asserted or printed here, because the
grid is frozen by a blind cost benchmark before any Δ is read (prereg §4).
"""
import sys
from fractions import Fraction

import pytest

sys.path.insert(0, __import__("os").path.dirname(__file__))
from test_shuffled_window import _visible_windows          # the census helper

from yupi.attribution import (COORDS, chain_terms, check_bijection, coords,
                              envelope, joint_entropy, latent_table, losses,
                              mass, normalized, per_observation,
                              per_offset_anchored, reconstruct, shapley,
                              subset_entropy, CoordCache, value_fn,
                              visible_table)
from yupi.config import WorldConfig
from yupi.programs import c0b_programs, c1_programs
from yupi.shuffled_window import shuffled_window_filter_with_evidence
from yupi.window import WindowLaw
from yupi.window_filter import filter_window_with_evidence

C0B = [("stochastic", "r2", WindowLaw(6, 4, 2), 64), ("fifo", "r4", WindowLaw(6, 4, 2), 56),
       ("stochastic", "r2", WindowLaw(6, 3, 3), 90), ("fifo", "r4", WindowLaw(6, 3, 3), 102)]


def _tables(cfg, progs, law, rung):
    lat = latent_table(cfg, progs, law, rung)
    vis, src = visible_table(lat, law.B)
    return lat, vis, src


@pytest.mark.parametrize("disc,rung,law,expected", C0B)
def test_visible_census_matches_helper_and_mass_is_one(disc, rung, law, expected):
    cfg, progs = WorldConfig.c0b(discipline=disc), c0b_programs()
    lat, vis, src = _tables(cfg, progs, law, rung)
    assert sum(mass(j) for j in lat.values()) == 1
    assert sum(mass(j) for j in vis.values()) == 1
    assert len(vis) == expected
    helper = {(tuple(tuple(b) for b in buckets), reset)
              for buckets, reset in _visible_windows(cfg, progs, law, rung)}
    assert {(v, r) for (r, v) in vis} == helper
    # every source mass is accounted for
    for v, j in vis.items():
        assert sum(src[v].values(), Fraction(0)) == mass(j)


@pytest.mark.parametrize("disc,rung,law,expected", C0B)
def test_gate2_both_paths_posterior_and_mass_every_observation(disc, rung, law, expected):
    """Prereg §5 gate 2 in table form: recursive filter == aggregated path
    table, joint (U, S_T) and law mass, for every distinct observation of
    both channels. Uncapped."""
    cfg, progs = WorldConfig.c0b(discipline=disc), c0b_programs()
    lat, vis, _ = _tables(cfg, progs, law, rung)
    for (reset, buckets), joint in vis.items():
        post, ev = shuffled_window_filter_with_evidence(
            cfg, progs, law, [list(b) for b in buckets], rung, reset)
        fj = {(u, s): w * m for u, (w, b) in post.components.items() for s, m in b.items()}
        assert fj == normalized(joint) and ev == mass(joint)
    for (reset, win), joint in lat.items():
        post, ev = filter_window_with_evidence(cfg, progs, law, list(win), rung, reset)
        fj = {(u, s): w * m for u, (w, b) in post.components.items() for s, m in b.items()}
        assert fj == normalized(joint) and ev == mass(joint)


@pytest.mark.parametrize("rung", ["r1", "r2", "r3", "r4"])
def test_Z3_B1_channel_is_identity_every_loss_zero(rung):
    cfg, progs = WorldConfig.c0b(discipline="stochastic"), c0b_programs()
    lat, vis, src = _tables(cfg, progs, WindowLaw(6, 3, 1), rung)
    assert len(lat) == len(vis)
    F = losses(lat, vis)
    assert all(f == 0.0 for f in F.values())
    assert all(g == 0.0 and not inf for _, _, g, inf in per_observation(lat, vis, src))


def test_gate_F_bijection_and_full_coordinate_identity():
    cfg, progs = WorldConfig.c1(epsilon=Fraction(1, 2)), c1_programs()
    lat, vis, _ = _tables(cfg, progs, WindowLaw(8, 4, 2), "r1")
    n = check_bijection(lat, vis)
    assert n > 100
    cache = CoordCache()
    for t in (lat, vis):
        assert subset_entropy(t, COORDS, cache) == joint_entropy(t)   # same partition, same floats
    # a hand case: two waiters queued in reverse index order, one in-flight request
    from yupi.state import RUNNABLE, RUNNING, State, io_blocked, lock_blocked
    s = State(pc=(1, 1, 2, 3), status=(RUNNING, lock_blocked(0), lock_blocked(0), io_blocked(1)),
              running=frozenset({0}), lock_owner=(0, None), lock_wq=((2, 1), ()),
              dev_q=(((3, 1),),), rr_cursor=2)
    c = coords(3, s)
    assert c["WQ"] == ((1, 0), ()) and c["DQ"] == ((0,),) and c["REQ"] == (((3, 1),),)
    assert c["kappa"] == 2 and c["U"] == 3 and c["rho"][1][3] == ("IO_BLOCKED",)
    assert reconstruct(c) == (3, s)


@pytest.mark.parametrize("cfg,progs,law,rung", [
    (WorldConfig.c0b(discipline="stochastic"), c0b_programs(), WindowLaw(6, 3, 3), "r2"),
    (WorldConfig.c1(epsilon=Fraction(1, 2)), c1_programs(), WindowLaw(8, 4, 2), "r1"),
    (WorldConfig.c1(epsilon=Fraction(1)), c1_programs(), WindowLaw(8, 4, 2), "r3"),
])
def test_gates_A_chain_shapley_envelope_identities(cfg, progs, law, rung):
    lat, vis, src = _tables(cfg, progs, law, rung)
    F = losses(lat, vis)
    d_un, off = F[frozenset(COORDS)], F[frozenset({"U"})]
    d_an = d_un - off
    assert d_un >= -1e-12 and off >= -1e-12 and d_an >= -1e-12
    for cond, players, total in ((frozenset(), COORDS, d_un),
                                 (frozenset({"U"}), COORDS[1:], d_an)):
        v = value_fn(F, cond)
        ch = chain_terms(v, players)
        assert all(t >= -1e-12 for t in ch.values())
        assert abs(sum(ch.values()) - total) < 1e-9
        sh = shapley(v, players)
        assert abs(sum(sh.values()) - total) < 1e-9
        env = envelope(v, players)
        for k in players:
            assert env[k][0] - 1e-12 <= ch[k] <= env[k][1] + 1e-12
            assert env[k][0] - 1e-12 <= sh[k] <= env[k][1] + 1e-12
    # per-observation gains integrate to Δ_un
    rows = per_observation(lat, vis, src)
    assert abs(sum(float(m) * g for _, m, g, _ in rows) - d_un) < 1e-9
    prev = sum((m for _, m, _, inf in rows if inf), Fraction(0))
    assert 0 <= prev <= 1
    assert all((g > 1e-12) <= inf for _, _, g, inf in rows)      # positive gain ⇒ exactly informative
    # per-endpoint anchored gains are law-mass consistent with Δ_an
    pe = per_offset_anchored(lat, vis, src, law)
    assert abs(sum(pe.values()) / len(pe) - d_an) < 1e-9


def test_Z1_kappa_term_exactly_zero_at_eps1_under_every_prefix():
    cfg, progs = WorldConfig.c1(epsilon=Fraction(1)), c1_programs()
    lat, vis, _ = _tables(cfg, progs, WindowLaw(8, 4, 2), "r1")
    F = losses(lat, vis)
    for A in F:
        if "kappa" not in A:
            assert F[A | {"kappa"}] == F[A]


def test_Z2_WQ_term_exactly_zero_at_c0b_under_every_prefix():
    cfg, progs = WorldConfig.c0b(discipline="fifo"), c0b_programs()
    lat, vis, _ = _tables(cfg, progs, WindowLaw(6, 3, 3), "r1")
    F = losses(lat, vis)
    for A in F:
        if "WQ" not in A:
            assert F[A | {"WQ"}] == F[A]


@pytest.mark.parametrize("cfg,progs,law,rung", [
    (WorldConfig.c0b(discipline="stochastic"), c0b_programs(), WindowLaw(6, 3, 3), "r2"),
    (WorldConfig.c1(epsilon=Fraction(1, 2)), c1_programs(), WindowLaw(8, 4, 2), "r1"),
    (WorldConfig.c1(epsilon=Fraction(1)), c1_programs(), WindowLaw(8, 4, 2), "r3"),
])
def test_losses_fast_path_is_bit_for_bit_the_reference(cfg, progs, law, rung):
    """The optimized losses() must equal a from-scratch computation built on
    the reference `subset_entropy` for EVERY subset — not close, identical —
    so the structural-zero gates (Z1/Z2/Z3) that read exact 0.0 differences
    cannot break. A float-normalized fast path was 6.3x faster and broke Z1;
    the shipped path keeps exact Fraction bucket sums (2.9x, bit-for-bit)."""
    lat, vis, _ = _tables(cfg, progs, law, rung)
    fast = losses(lat, vis)
    cache = CoordCache()
    n = len(COORDS)
    ref = {}
    for bits in range(1 << n):
        A = tuple(p for i, p in enumerate(COORDS) if bits >> i & 1)
        ref[frozenset(A)] = (subset_entropy(vis, A, cache) - subset_entropy(lat, A, cache)) if A else 0.0
    assert fast.keys() == ref.keys()
    for k in ref:
        assert fast[k] == ref[k], (sorted(k), fast[k], ref[k])   # bit-for-bit
    # and the exact gates the speed must not break
    assert all(fast[A | {"kappa"}] == fast[A] for A in fast if "kappa" not in A) or cfg.epsilon != 1


def test_per_endpoint_conditions_on_endpoint_not_offset_pooled():
    """Truthsayer review 2026-08-29, Finding 1: per-endpoint gains must be
    restricted to windows generated at T (prereg §7). The pre-fix code selected
    joint entries by offset u alone, and every reset-visible endpoint T ≤ L has
    u = 0, so full-context laws reported the law-level mean at every endpoint.
    Corrected expectation at C1 ε = ½, (6,6,2), r4: the whole cursor loss is at
    endpoint 2 and equals the reviewer's closed form
    C = 7/16 h(1/21) + 1/8 h(1/6) + 5/24 h(1/5) + 3/16 h(4/9) + 1/24 h(1/2);
    endpoints 4 and 6 are exactly 0; the mean is the law-level Δ."""
    import math
    from yupi.d8_measure import per_offset_unanchored
    h = lambda p: -(p * math.log2(p) + (1 - p) * math.log2(1 - p))
    C = 7 / 16 * h(1 / 21) + 1 / 8 * h(1 / 6) + 5 / 24 * h(1 / 5) + 3 / 16 * h(4 / 9) + 1 / 24 * h(1 / 2)
    cfg, progs = WorldConfig.c1(epsilon=Fraction(1, 2)), c1_programs()
    law = WindowLaw(6, 6, 2)
    lat, vis, src = _tables(cfg, progs, law, "r4")
    pa = per_offset_anchored(lat, vis, src, law)
    pu = per_offset_unanchored(lat, vis, law)
    assert set(pa) == {2, 4, 6}
    assert abs(pa[2] - C) < 1e-15 and pa[4] == 0.0 and pa[6] == 0.0
    assert abs(pu[2] - C) < 1e-15 and pu[4] == 0.0 and pu[6] == 0.0
    assert len({round(v, 12) for v in pa.values()}) == 2          # {C, 0}: NOT one pooled value copied per endpoint
    assert abs(sum(pa.values()) / 3 - C / 3) < 1e-15               # law mean = Δ_an = C / (T_ep/2)


def test_per_endpoint_localizes_the_1_over_108_at_9_9_3_to_endpoint_9():
    """Same finding, second regularity: C1 ε = 1, (9,9,3), r4 — the artifact's
    law-level 1/108 is the mean of {3: 0, 6: 0, 9: 1/36}: the wait-queue bit is
    lost only on windows generated at endpoint 9 (mass 1/36, one bit each)."""
    cfg, progs = WorldConfig.c1(epsilon=Fraction(1)), c1_programs()
    law = WindowLaw(9, 9, 3)
    lat, vis, src = _tables(cfg, progs, law, "r4")
    pa = per_offset_anchored(lat, vis, src, law)
    assert pa[3] == 0.0 and pa[6] == 0.0 and abs(pa[9] - 1 / 36) < 1e-13
    assert abs(sum(pa.values()) / 3 - 1 / 108) < 1e-13
