"""Witness tests for the 2026-08-20 direct-handoff audit findings.

Statute anchors: Part II §3.3 (RELEASE: the woken head "acquires ownership
immediately and becomes RUNNABLE" — its ACQUIRE is complete, so its pc must
advance at handoff), §3.5 (direct handoff), §3.6/§2 (episodes are exactly
T_ep records; the terminal state is an absorbing IDLE self-loop), I6 (no
deadlock state reachable). Written failing against the defective kernel
(commit 47b4019 era), per the audit's reproduction.
"""
from fractions import Fraction

import pytest

from yupi.config import WorldConfig
from yupi.enumerator import paths
from yupi.kernel import enabled
from yupi.programs import c0a_programs, c0b_programs, c1_programs, validate_lock_order
from yupi.simulator import sample_episode
from yupi.state import check_invariants, initial_state, TERMINATED


def _self_wait(state):
    return any(
        owner is not None and owner in state.lock_wq[lock]
        for lock, owner in enumerate(state.lock_owner)
    )


def _first_self_wait_transition(cfg, programs, horizon):
    """Walk every path; return a (state_before, transition) pair whose next
    state self-waits, or None."""
    frontier = [(initial_state(cfg), Fraction(1))]
    for _ in range(horizon):
        nxt = []
        for s, p in frontier:
            for t, q in enabled(s, cfg, programs):
                if _self_wait(t.next_state):
                    return s, t
                nxt.append((t.next_state, p * q))
        frontier = nxt
    return None


def test_handoff_advances_woken_pc_past_acquire():
    """After a RELEASE handoff, the woken thread's pc has moved past its
    ACQUIRE (statute: it acquired immediately)."""
    cfg, programs = WorldConfig.c0a(), c0a_programs()
    seen_handoff = False
    frontier = [initial_state(cfg)]
    seen = set()
    for _ in range(12):
        nxt = []
        for s in frontier:
            for t, _ in enabled(s, cfg, programs):
                if t.kind == "RELEASE" and t.related is not None:
                    seen_handoff = True
                    woken = t.related
                    ns = t.next_state
                    instr = programs[woken][ns.pc[woken]] if ns.pc[woken] < len(programs[woken]) else None
                    assert not (instr is not None and instr[0] == "ACQUIRE" and t.obj == ("LOCK", instr[1])), (
                        "woken thread's pc still points at the ACQUIRE it was handed"
                    )
                if t.next_state not in seen:
                    seen.add(t.next_state)
                    nxt.append(t.next_state)
        frontier = nxt
    assert seen_handoff, "no handoff reached — witness vacuous"


def test_no_self_wait_reachable_c0a_horizon_12():
    """Exact enumeration: no endpoint state to horizon 12 has a lock owner
    queued on its own lock (audit: mass 1/8 at T=10, 11/32 at T=12)."""
    cfg, programs = WorldConfig.c0a(), c0a_programs()
    for T in (10, 12):
        bad = sum((p for _, p, f in paths(cfg, programs, T) if _self_wait(f)), Fraction(0))
        assert bad == 0, f"self-wait mass {bad} at T={T}"


def test_no_self_wait_reachable_c1_first_contamination_tick():
    cfg, programs = WorldConfig.c1(epsilon=Fraction(1)), c1_programs()
    bad = sum((p for _, p, f in paths(cfg, programs, 11) if _self_wait(f)), Fraction(0))
    assert bad == 0, f"self-wait mass {bad} at T=11 (audit measured 1/384 at 11–12)"


def test_no_self_wait_transition_anywhere_c0a():
    assert _first_self_wait_transition(WorldConfig.c0a(), c0a_programs(), 12) is None


def test_check_invariants_flags_self_wait():
    """I6 (deadlock): an owner queued on its own lock must be reported."""
    from dataclasses import replace
    from yupi.state import lock_blocked
    cfg, programs = WorldConfig.c0a(), c0a_programs()
    s = initial_state(cfg)
    # Synthesize the audit's bad state shape: thread 0 owns lock 0 AND waits on it.
    bad = replace(
        s,
        lock_owner=(0,) + s.lock_owner[1:],
        lock_wq=((0,),) + s.lock_wq[1:],
        status=(lock_blocked(0),) + s.status[1:],
        running=s.running - {0},
    )
    assert "I6" in check_invariants(bad, cfg)


def test_sample_episode_emits_exactly_horizon_records():
    """Statute §2: exactly T_ep transition records, absorbing IDLE tail
    (audit: sample_episode returned 11 of 40 for this seed)."""
    cfg, programs = WorldConfig.c0b("fifo"), c0b_programs()
    episode = sample_episode(cfg, programs, 40, 0)
    assert len(episode) == 40
    # Once all threads terminate, every remaining record is IDLE.
    terminated_at = None
    for i, (t, r) in enumerate(episode):
        if all(st == TERMINATED for st in t.next_state.status) and terminated_at is None:
            terminated_at = i
        if terminated_at is not None and i > terminated_at:
            assert r.kind == "IDLE"
    assert terminated_at is not None and terminated_at < 39


def test_validate_lock_order_rejects_unreleased_lock():
    """Finding 10: a program ending while holding a lock is outside the
    declared machine (I3/I6) and must be rejected."""
    assert not validate_lock_order(((("ACQUIRE", 0),),))


def test_reachable_space_satisfies_all_invariants():
    """Exhaustive model check: every state reachable in C0a (full space) and
    C1 (to horizon 8) satisfies I1-I6 (I2 as statutory mutual exclusion, I6 as blocked-cycle
    detection over the lock wait-for graph -- round-two strengthening). The
    enumerative walk also exercises the
    kernel's transition-site guards (KernelInvariantViolation) on every
    reachable transition -- embedded invariants become horizon-bounded proofs.
    """
    for cfg, programs, horizon in (
        (WorldConfig.c0a(), c0a_programs(), None),      # full reachable space
        (WorldConfig.c1(epsilon=Fraction(1)), c1_programs(), 8),
    ):
        frontier, seen, depth = [initial_state(cfg)], set(), 0
        while frontier and (horizon is None or depth < horizon):
            nxt = []
            for s in frontier:
                for t, _ in enabled(s, cfg, programs):
                    ns = t.next_state
                    if ns not in seen:
                        seen.add(ns)
                        assert check_invariants(ns, cfg) == [], (t.kind, ns)
                        nxt.append(ns)
            frontier, depth = nxt, depth + 1
        assert seen


def test_kernel_guard_fires_on_self_acquire():
    """The buggy kernel's post-handoff shape -- a thread executing ACQUIRE on
    a lock it already owns -- must raise KernelInvariantViolation, not
    silently self-block. This is the tripwire that would have caught the
    2026-08-20 defect on the first enumerated path."""
    from dataclasses import replace
    from yupi.kernel import KernelInvariantViolation
    from yupi.state import RUNNING
    cfg, programs = WorldConfig.c0a(), c0a_programs()
    s = initial_state(cfg)
    # thread 0 owns lock 0 yet is RUNNING with pc on its ACQUIRE(0)
    acq_pc = next(i for i, ins in enumerate(programs[0]) if ins == ("ACQUIRE", 0))
    bad = replace(
        s,
        pc=(acq_pc,) + s.pc[1:],
        lock_owner=(0,) + s.lock_owner[1:],
        status=(RUNNING,) + s.status[1:],
        running=frozenset({0}),
    )
    with pytest.raises(KernelInvariantViolation):
        enabled(bad, cfg, programs)


def test_check_invariants_flags_lock_cycle():
    """Statutory I6: a blocked cycle (T0 owns L0 waits L1; T1 owns L1 waits
    L0) must be reported. The self-wait case is the 1-cycle."""
    from dataclasses import replace
    from yupi.state import lock_blocked
    cfg = WorldConfig.c1(epsilon=Fraction(1))
    s = initial_state(cfg)
    cyc = replace(
        s,
        lock_owner=(0, 1) + s.lock_owner[2:],
        lock_wq=((1,), (0,)) + s.lock_wq[2:],
        status=(lock_blocked(1), lock_blocked(0)) + s.status[2:],
        running=frozenset(),
    )
    assert "I6" in check_invariants(cyc, cfg)


def test_check_invariants_flags_running_thread_in_wait_queue():
    """Statutory I2: a thread appears in at most one of run, a lock wq, the
    in-flight relation -- RUNNING while queued must be reported."""
    from dataclasses import replace
    from yupi.state import RUNNING
    cfg = WorldConfig.c0a()
    s = initial_state(cfg)
    bad = replace(
        s,
        lock_wq=((0,),) + s.lock_wq[1:],
        status=(RUNNING,) + s.status[1:],
        running=frozenset({0}),
    )
    assert "I2" in check_invariants(bad, cfg)


def test_kernel_rejects_invalid_programs():
    """Finding 3 (second round): the validator must be enforced at the kernel
    boundary, not merely available -- (ACQUIRE(0),) terminates while owning."""
    from yupi.kernel import KernelInvariantViolation
    cfg = WorldConfig.c0a()
    with pytest.raises(KernelInvariantViolation):
        enabled(initial_state(cfg), cfg, ((("ACQUIRE", 0),),))
