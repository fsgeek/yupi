"""First gated live-world ceilings: (40,8,2), looping C1′, r4, ε = 1
(`docs/c1prime-loop-query-ceilings-40-8-2-r4-2026-09-04.json`, produced on
the recursion under the external sharded gate). Pins: the gate field names
the eight all-exact shard raws; the law-mass H(S) equals the pass-pricing
raw's r4 value (two independent runs of the recursion); the U = 0 part of
H(S) is exactly zero (reset-anchored r4 windows are injective in the
looping world too); the statutory query means. Statutory set per Part II
§5 (`statutory_queries`; corrected 2026-09-12). Exploratory until Part II
v0.2.8.1 / v0.2.7.1 are enacted; gated regardless."""
import json
import pathlib

from yupi.sync import conditional_from_by_endpoint
from yupi.window import WindowLaw

DOCS = pathlib.Path(__file__).parent.parent / "docs"

STATUTORY = ("Q1[L0]", "Q1[L1]", "Q2[T0]", "Q2[T1]", "Q2[T2]", "Q2[T3]", "Q3[D0]")


def statutory_queries(queries):
    """Part II §5's statutory query set as keyed in the query-ceilings
    artifacts: Q1[L0], Q1[L1], Q2[T0..T3], Q3[D0], and the twelve ordered
    Q5 pairs. NOT in the set: Q3thr[D0] and Q4proxy (proxies) and Q5joint
    (reported beside the maximum, v0.2.5). Q4 enters by its gap part at
    W = 4 (v0.2.5 §A′) from the q4 artifacts — see `statutory_gaps`.
    Corrected 2026-09-12 per the exit-clause note's [rv-1]: until then the
    `stat` lists below held Q5joint and lacked Q4. No pinned maximum
    changed (Q4's adjacent differences are 0.0195 / 0.0291 / 0.0034 at
    ε = 1 and 0.0148 / 0.0160 / 0.0027 at ε = ½, below every carrier)."""
    keys = [k for k in queries if k in STATUTORY or k.startswith("Q5[")]
    assert len(keys) == 19, keys
    return keys


def q4_gap_bits(rung, eps):
    """Q4's gap part at W = 4 for (rung, ε) from the pinned q4 artifact."""
    pat = f"c1prime-loop-q4-ceilings-40-8-2-{rung}-W4-????-??-??" + ("" if eps == "1" else "-eps1_2") + ".json"
    (f,) = DOCS.glob(pat)
    (r,) = json.load(open(f))["rows"]
    assert r["rung"] == rung and r["eps"] == eps
    return r["gap_bits"]


def statutory_gaps(coarse, fine):
    """Coarser row minus finer row, per statutory query, Q4 by its gap part."""
    g = {k: coarse["queries"][k]["mean_bits"] - fine["queries"][k]["mean_bits"] for k in statutory_queries(coarse["queries"])}
    g["Q4gap[W4]"] = q4_gap_bits(coarse["rung"], coarse["eps"]) - q4_gap_bits(fine["rung"], fine["eps"])
    return g


def _row():
    d = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-04.json"))
    assert d["aggregation"] == "window" and d["gate"] == "external" and d["programs"] == "c1prime-loop"
    (r,) = d["rows"]
    assert r["eps"] == "1" and r["rung"] == "r4"
    return r


def test_gate_field_names_the_eight_exact_shards():
    r = _row()
    files = r["gate"].removeprefix("external:").split(",")
    assert len(files) == 8 and all(f.startswith("window-gate-c1prime-loop-40-8-2-r4-2026-09-04-full-shard") for f in files)
    for f in files:
        (g,) = json.load(open(DOCS / f))["rows"]
        assert g["mismatches"] == []


def test_state_entropy_matches_the_pass_pricing_raw_and_has_no_reset_part():
    r = _row()
    p = json.load(open(DOCS / "window-process-pass-pricing-c1prime-loop-40-8-2-2026-09-04.json"))
    pr = next(x for x in p["rows"] if x["eps"] == "1")
    assert r["n_windows"] == 1524612 == pr["per_rung"]["r4"]["n_windows"]
    assert abs(r["mean_state_entropy_bits"] - pr["per_rung"]["r4"]["mean_state_entropy_bits"]) < 1e-9
    c = conditional_from_by_endpoint(r["by_endpoint"], WindowLaw(T_ep=40, L=8, B=2), "mean_state_entropy_bits")
    assert c["H_U0"] == 0.0 and round(c["E_H_given_U_pos"], 4) == 0.4873


def test_statutory_query_means_pinned():
    q = _row()["queries"]
    for k, v in (("Q1[L0]", 0.0170), ("Q1[L1]", 0.0402), ("Q2[T0]", 0.0502), ("Q2[T1]", 0.0228),
                 ("Q2[T2]", 0.0456), ("Q2[T3]", 0.0117), ("Q3[D0]", 0.0141), ("Q5joint", 0.0606)):
        assert round(q[k]["mean_bits"], 4) == v, k
    assert round(q["Q1[L0]"]["resolved_mass"], 3) == 0.983


def test_q4_and_predictive_targets_at_the_same_gated_law_pinned():
    """Q4 (W = 4) and the τ family at (40,8,2) r4 ε = 1, produced on the
    recursion; they carry no gate of their own and are covered by the r4
    ε = 1 sharded gate (their docstrings say so). Raws filed 2026-09-05."""
    q = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r4-W4-2026-09-05.json"))
    assert q["aggregation"] == "window" and q["programs"] == "c1prime-loop" and q["W"] == 4
    (r,) = q["rows"]
    assert r["eps"] == "1" and r["rung"] == "r4" and r["n_windows"] == 1524612 and r["n_states"] == 1973
    assert (round(r["total_bits"], 4), round(r["irreducible_bits"], 4), round(r["gap_bits"], 4), round(r["none_mass"], 4)) == (0.9122, 0.8361, 0.0761, 0.4454)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r4-2026-09-05.json"))
    assert t["aggregation"] == "window" and t["m"] == 2 and t["W"] == 4
    (s,) = t["rows"]
    assert s["n_windows"] == 1524612 and s["n_pnext_classes"] == 37523
    assert round(s["means"]["pnext"]["gap"], 4) == 0.1026 and round(s["means"]["kinds2"]["gap"], 4) == 0.1191
    assert round(s["means"]["ttw4"]["gap"], 4) == 0.0572 and round(s["means"]["lineage4"]["gap"], 4) == 0.0226
    d = s["divergent"]
    assert d["pairs"] == 15247291009 and d["windows"] == 1196345 and round(d["mass"], 4) == 0.6698
    assert round(d["pair_prob"], 6) == 0.008817 and round(d["tv_pair_prob"], 6) == 0.004691


def test_r4_eps_half_three_artifacts_pinned():
    """The same three producers at (40,8,2) r4, ε = ½, under the r4 ε = ½
    sharded gate (raws filed 2026-09-05)."""
    q = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-05-eps1_2.json"))
    (r,) = q["rows"]
    assert r["eps"] == "1/2" and r["n_windows"] == 1524612
    assert r["gate"].count("full-eps1_2-shard") == 8
    assert round(r["mean_state_entropy_bits"], 4) == 0.1658
    for k, v in (("Q1[L0]", 0.0032), ("Q1[L1]", 0.0209), ("Q2[T0]", 0.0186), ("Q3[D0]", 0.0098), ("Q5joint", 0.0243)):
        assert round(r["queries"][k]["mean_bits"], 4) == v, k
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r4-W4-2026-09-05-eps1_2.json"))["rows"][0]
    assert q4["eps"] == "1/2" and q4["n_states"] == 4231
    assert (round(q4["total_bits"], 4), round(q4["irreducible_bits"], 4), round(q4["gap_bits"], 4), round(q4["none_mass"], 4)) == (0.7573, 0.7205, 0.0368, 0.4144)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r4-2026-09-05-eps1_2.json"))["rows"][0]
    assert t["eps"] == "1/2" and t["n_pnext_classes"] == 87421
    assert round(t["means"]["pnext"]["gap"], 4) == 0.0561 and round(t["means"]["kinds2"]["gap"], 4) == 0.0683
    assert t["divergent"]["pairs"] == 7280573310 and t["divergent"]["windows"] == 1182875 and round(t["divergent"]["mass"], 4) == 0.7184


def test_r1_eps1_three_artifacts_pinned_and_r1_to_r4_gap_is_above_delta():
    """r1 at (40,8,2) ε = 1 under the r1 ε = 1 sharded gate (raws 2026-09-05),
    and the first statutory-query rung gap in a live world at context 8:
    r1 → r4 on Q1[L0] is 0.1439 bits, fourteen times δ = 0.01 (exploratory
    until enactment; adjacent pairs await the r2 and r3 gates)."""
    q1 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05.json"))
    (r,) = q1["rows"]
    assert r["eps"] == "1" and r["rung"] == "r1" and r["n_windows"] == 819073 and r["gate"].count("-r1-2026-09-05-full-shard") == 8
    assert round(r["mean_state_entropy_bits"], 4) == 0.6008
    for k, v in (("Q1[L0]", 0.1609), ("Q1[L1]", 0.1021), ("Q2[T0]", 0.0996), ("Q3[D0]", 0.0313), ("Q5joint", 0.1177)):
        assert round(r["queries"][k]["mean_bits"], 4) == v, k
    r4 = _row()
    gap = r["queries"]["Q1[L0]"]["mean_bits"] - r4["queries"]["Q1[L0]"]["mean_bits"]
    assert round(gap, 4) == 0.1439 and gap > 10 * 0.01
    assert all(r["queries"][k]["mean_bits"] >= r4["queries"][k]["mean_bits"] - 1e-12 for k in r["queries"])   # refinement
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r1-W4-2026-09-05.json"))["rows"][0]
    assert q4["rung"] == "r1" and (round(q4["total_bits"], 4), round(q4["irreducible_bits"], 4), round(q4["gap_bits"], 4)) == (0.9642, 0.8361, 0.1281)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r1-2026-09-05.json"))["rows"][0]
    assert t["rung"] == "r1" and t["n_pnext_classes"] == 37879 and round(t["means"]["kinds2"]["gap"], 4) == 0.1858
    assert t["divergent"]["windows"] == 630007 and round(t["divergent"]["mass"], 4) == 0.6085


def test_r1_eps_half_three_artifacts_pinned_and_gap_to_r4():
    """r1 at (40,8,2) ε = ½ under the r1 ε = ½ gate (raws 2026-09-05): the
    r1 → r4 gap on Q1[L0] is 0.0764 bits, seven times δ."""
    q1 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05-eps1_2.json"))
    (r,) = q1["rows"]
    assert r["eps"] == "1/2" and r["rung"] == "r1" and r["n_windows"] == 819073 and r["gate"].count("eps1_2-shard") == 8
    assert round(r["mean_state_entropy_bits"], 4) == 0.2963
    for k, v in (("Q1[L0]", 0.0796), ("Q1[L1]", 0.0682), ("Q2[T0]", 0.0453), ("Q3[D0]", 0.0247), ("Q5joint", 0.0576)):
        assert round(r["queries"][k]["mean_bits"], 4) == v, k
    r4 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-05-eps1_2.json"))["rows"][0]
    assert round(r["queries"]["Q1[L0]"]["mean_bits"] - r4["queries"]["Q1[L0]"]["mean_bits"], 4) == 0.0764
    assert all(r["queries"][k]["mean_bits"] >= r4["queries"][k]["mean_bits"] - 1e-12 for k in r["queries"])
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r1-W4-2026-09-05-eps1_2.json"))["rows"][0]
    assert (round(q4["total_bits"], 4), round(q4["irreducible_bits"], 4), round(q4["gap_bits"], 4)) == (0.7908, 0.7205, 0.0703)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r1-2026-09-05-eps1_2.json"))["rows"][0]
    assert t["n_pnext_classes"] == 78472 and round(t["means"]["kinds2"]["gap"], 4) == 0.1154
    assert t["divergent"]["windows"] == 619385 and round(t["divergent"]["mass"], 4) == 0.6598


def test_r2_eps1_three_artifacts_pinned_and_first_adjacent_pair_clears_delta():
    """r2 at (40,8,2) ε = 1 under the r2 ε = 1 gate (raws 2026-09-05). The
    first ADJACENT rung pair in a live world at context 8 on the statutory
    set: r1 → r2 max gap 0.0477 bits (Q1[L1]), 4.8× δ; Q1[L0] 0.0339,
    Q5joint 0.0263; r2 → r4 on Q1[L0] 0.1100. Exploratory until enactment."""
    q2 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r2-2026-09-05.json"))
    (r2,) = q2["rows"]
    assert r2["eps"] == "1" and r2["rung"] == "r2" and r2["n_windows"] == 923461 and r2["gate"].count("-r2-2026-09-05-full-shard") == 8
    assert round(r2["mean_state_entropy_bits"], 4) == 0.5277
    for k, v in (("Q1[L0]", 0.1270), ("Q1[L1]", 0.0544), ("Q2[T0]", 0.0906), ("Q3[D0]", 0.0312), ("Q5joint", 0.0914)):
        assert round(r2["queries"][k]["mean_bits"], 4) == v, k
    r1 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05.json"))["rows"][0]
    r4 = _row()
    stat = statutory_queries(r1["queries"])
    gaps12 = statutory_gaps(r1, r2)
    assert max(gaps12, key=gaps12.get) == "Q1[L1]" and round(max(gaps12.values()), 4) == 0.0477
    assert round(gaps12["Q1[L0]"], 4) == 0.0339 and round(gaps12["Q4gap[W4]"], 4) == 0.0195
    assert round(r1["queries"]["Q5joint"]["mean_bits"] - r2["queries"]["Q5joint"]["mean_bits"], 4) == 0.0263   # beside the set
    assert max(gaps12.values()) > 4 * 0.01
    assert all(r1["queries"][k]["mean_bits"] >= r2["queries"][k]["mean_bits"] - 1e-12 >= r4["queries"][k]["mean_bits"] - 2e-12 for k in stat)
    assert round(r2["queries"]["Q1[L0]"]["mean_bits"] - r4["queries"]["Q1[L0]"]["mean_bits"], 4) == 0.1100
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r2-W4-2026-09-05.json"))["rows"][0]
    assert q4["rung"] == "r2" and (round(q4["total_bits"], 4), round(q4["gap_bits"], 4)) == (0.9447, 0.1086)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r2-2026-09-05.json"))["rows"][0]
    assert t["rung"] == "r2" and t["n_pnext_classes"] == 34844 and round(t["means"]["kinds2"]["gap"], 4) == 0.1572
    assert t["divergent"]["windows"] == 743375 and round(t["divergent"]["mass"], 4) == 0.6377


def test_r2_eps_half_three_artifacts_pinned_and_adjacent_pair_clears_delta():
    """r2 at (40,8,2) ε = ½ under the r2 ε = ½ gate (raws 2026-09-05): the
    r1 → r2 max gap is 0.0366 bits (Q1[L1]), 3.7× δ; Q1[L0] 0.0241, Q5joint
    0.0178; r2 → r4 on Q1[L0] 0.0523."""
    (r2,) = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r2-2026-09-05-eps1_2.json"))["rows"]
    assert r2["eps"] == "1/2" and r2["rung"] == "r2" and r2["n_windows"] == 923461 and r2["gate"].count("-r2-2026-09-05-full-eps1_2-shard") == 8
    assert round(r2["mean_state_entropy_bits"], 4) == 0.2400
    for k, v in (("Q1[L0]", 0.0555), ("Q1[L1]", 0.0315), ("Q2[T0]", 0.0415), ("Q3[D0]", 0.0247), ("Q5joint", 0.0398)):
        assert round(r2["queries"][k]["mean_bits"], 4) == v, k
    r1 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05-eps1_2.json"))["rows"][0]
    r4 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-05-eps1_2.json"))["rows"][0]
    stat = statutory_queries(r1["queries"])
    g12 = statutory_gaps(r1, r2)
    assert max(g12, key=g12.get) == "Q1[L1]" and round(max(g12.values()), 4) == 0.0366 and max(g12.values()) > 3 * 0.01
    assert round(g12["Q1[L0]"], 4) == 0.0241 and round(g12["Q4gap[W4]"], 4) == 0.0148
    assert round(r1["queries"]["Q5joint"]["mean_bits"] - r2["queries"]["Q5joint"]["mean_bits"], 4) == 0.0178   # beside the set
    assert round(r2["queries"]["Q1[L0]"]["mean_bits"] - r4["queries"]["Q1[L0]"]["mean_bits"], 4) == 0.0523
    assert all(r1["queries"][k]["mean_bits"] >= r2["queries"][k]["mean_bits"] - 1e-12 >= r4["queries"][k]["mean_bits"] - 2e-12 for k in stat)
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r2-W4-2026-09-05-eps1_2.json"))["rows"][0]
    assert (round(q4["total_bits"], 4), round(q4["gap_bits"], 4)) == (0.7760, 0.0555)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r2-2026-09-05-eps1_2.json"))["rows"][0]
    assert t["n_pnext_classes"] == 75278 and round(t["means"]["kinds2"]["gap"], 4) == 0.0916
    assert t["divergent"]["windows"] == 732715 and round(t["divergent"]["mass"], 4) == 0.6902


def test_r3_eps1_pinned_and_every_adjacent_pair_is_above_delta_at_eps1():
    """r3 at (40,8,2) ε = 1 under the r3 ε = 1 gate (raws 2026-09-06)
    completes the r1–r4 ladder at ε = 1. Every adjacent pair on the complete
    statutory query set is above δ = 0.01 bits: r1 → r2 0.0477 (Q1[L1]),
    r2 → r3 0.1100 (Q1[L0]), r3 → r4 0.0142 (Q3[D0]); the lineage step is
    carried by the device query and is the thinnest at 1.4× δ. Every query
    refines monotonically down the ladder. Exploratory until enactment."""
    files = {"r1": "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05.json", "r2": "c1prime-loop-query-ceilings-40-8-2-r2-2026-09-05.json",
             "r3": "c1prime-loop-query-ceilings-40-8-2-r3-2026-09-06.json", "r4": "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-04.json"}
    R = {r: json.load(open(DOCS / f))["rows"][0] for r, f in files.items()}
    r3 = R["r3"]
    assert r3["eps"] == "1" and r3["rung"] == "r3" and r3["n_windows"] == 991585 and r3["gate"].count("-r3-2026-09-06-full-shard") == 8
    assert round(r3["mean_state_entropy_bits"], 4) == 0.4046
    for k, v in (("Q1[L0]", 0.0170), ("Q1[L1]", 0.0404), ("Q2[T0]", 0.0584), ("Q3[D0]", 0.0283), ("Q5joint", 0.0642)):
        assert round(r3["queries"][k]["mean_bits"], 4) == v, k
    stat = statutory_queries(R["r1"]["queries"])
    expected = {("r1", "r2"): ("Q1[L1]", 0.0477), ("r2", "r3"): ("Q1[L0]", 0.1100), ("r3", "r4"): ("Q3[D0]", 0.0142)}
    for (a, b), (q, v) in expected.items():
        g = statutory_gaps(R[a], R[b])
        assert max(g, key=g.get) == q and round(max(g.values()), 4) == v, (a, b)
        assert max(g.values()) > 0.01                       # δ, frozen v0.2.5
        assert all(x >= -1e-12 for x in g.values()), (a, b)  # refinement
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r3-W4-2026-09-06.json"))["rows"][0]
    assert q4["rung"] == "r3" and (round(q4["total_bits"], 4), round(q4["gap_bits"], 4)) == (0.9156, 0.0795)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r3-2026-09-06.json"))["rows"][0]
    assert t["rung"] == "r3" and t["n_pnext_classes"] == 28685 and round(t["means"]["kinds2"]["gap"], 4) == 0.1239
    assert t["divergent"]["windows"] == 799106 and round(t["divergent"]["mass"], 4) == 0.7113


def test_r0_eps1_pinned_identity_step_and_nonzero_reset_part():
    """r0 (kind-only) at (40,8,2) ε = 1 under the r0 ε = 1 gate (raws
    2026-09-06). The r0 → r1 step is the largest on the axis by an order of
    magnitude: Q2[T0] 1.0769 bits, Q5joint 0.9394, Q1[L0] 0.8337; every
    query refines. And r0 is the first rung whose reset-anchored part of
    H(S) is not zero (0.5395 bits), so v0.2.7.1 Clause 2's corrected
    synchronization formula changes a number here for the first time:
    E[H | U > 0] = 4.2598 against the v0.2.5 closed form's 4.9342."""
    (r0,) = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r0-2026-09-06.json"))["rows"]
    assert r0["eps"] == "1" and r0["rung"] == "r0" and r0["n_windows"] == 12739 and r0["gate"].count("-r0-2026-09-06-full-shard") == 8
    assert round(r0["mean_state_entropy_bits"], 4) == 3.9474
    for k, v in (("Q1[L0]", 0.9946), ("Q1[L1]", 0.6154), ("Q2[T0]", 1.1765), ("Q2[T3]", 0.8303), ("Q3[D0]", 0.1949), ("Q5joint", 1.0571)):
        assert round(r0["queries"][k]["mean_bits"], 4) == v, k
    r1 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05.json"))["rows"][0]
    g = statutory_gaps(r0, r1)
    assert max(g, key=g.get) == "Q2[T0]" and round(max(g.values()), 4) == 1.0769 and all(v >= -1e-12 for v in g.values())
    assert round(g["Q1[L0]"], 4) == 0.8337 and round(r0["queries"]["Q5joint"]["mean_bits"] - r1["queries"]["Q5joint"]["mean_bits"], 4) == 0.9394
    c = conditional_from_by_endpoint(r0["by_endpoint"], WindowLaw(T_ep=40, L=8, B=2), "mean_state_entropy_bits")
    assert round(c["H_U0"], 4) == 0.5395 and round(c["E_H_given_U_pos"], 4) == 4.2598
    assert round(c["H_law"] * 40 / 32, 4) == 4.9342 and c["E_H_given_U_pos"] < c["H_law"] * 40 / 32 - 0.5
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r0-W4-2026-09-06.json"))["rows"][0]
    assert q4["rung"] == "r0" and (round(q4["total_bits"], 4), round(q4["irreducible_bits"], 4), round(q4["gap_bits"], 4)) == (1.5390, 0.8361, 0.7029)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r0-2026-09-06.json"))["rows"][0]
    assert t["rung"] == "r0" and t["n_pnext_classes"] == 4417 and round(t["means"]["kinds2"]["gap"], 4) == 0.7544
    assert t["divergent"]["windows"] == 6732 and round(t["divergent"]["mass"], 4) == 0.2018


def test_r3_eps_half_pinned_and_every_adjacent_pair_is_above_delta_at_eps_half():
    """r3 at (40,8,2) ε = ½ under the r3 ε = ½ gate (raws 2026-09-06)
    completes the r1–r4 ladder at ε = ½. Every adjacent pair is above δ:
    r1 → r2 0.0366 (Q1[L1]), r2 → r3 0.0523 (Q1[L0]), r3 → r4 0.0113
    (Q3[D0]) — the lineage step clears δ by 13 % at this setting, the
    thinnest margin on either ladder. Every query refines monotonically."""
    files = {"r1": "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05-eps1_2.json", "r2": "c1prime-loop-query-ceilings-40-8-2-r2-2026-09-05-eps1_2.json",
             "r3": "c1prime-loop-query-ceilings-40-8-2-r3-2026-09-06-eps1_2.json", "r4": "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-05-eps1_2.json"}
    R = {r: json.load(open(DOCS / f))["rows"][0] for r, f in files.items()}
    r3 = R["r3"]
    assert r3["eps"] == "1/2" and r3["rung"] == "r3" and r3["n_windows"] == 991585 and r3["gate"].count("-r3-2026-09-06-full-eps1_2-shard") == 8
    assert round(r3["mean_state_entropy_bits"], 4) == 0.1774
    for k, v in (("Q1[L0]", 0.0032), ("Q1[L1]", 0.0210), ("Q2[T0]", 0.0255), ("Q3[D0]", 0.0210), ("Q5joint", 0.0288)):
        assert round(r3["queries"][k]["mean_bits"], 4) == v, k
    stat = statutory_queries(R["r1"]["queries"])
    expected = {("r1", "r2"): ("Q1[L1]", 0.0366), ("r2", "r3"): ("Q1[L0]", 0.0523), ("r3", "r4"): ("Q3[D0]", 0.0113)}
    for (a, b), (q, v) in expected.items():
        g = statutory_gaps(R[a], R[b])
        assert max(g, key=g.get) == q and round(max(g.values()), 4) == v, (a, b)
        assert max(g.values()) > 0.01 and all(x >= -1e-12 for x in g.values()), (a, b)
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r3-W4-2026-09-06-eps1_2.json"))["rows"][0]
    assert q4["rung"] == "r3" and (round(q4["total_bits"], 4), round(q4["gap_bits"], 4)) == (0.7600, 0.0395)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r3-2026-09-06-eps1_2.json"))["rows"][0]
    assert t["rung"] == "r3" and t["n_pnext_classes"] == 67620 and round(t["means"]["kinds2"]["gap"], 4) == 0.0716
    assert t["divergent"]["windows"] == 787304 and round(t["divergent"]["mass"], 4) == 0.7642


def test_r0_eps_half_pinned_and_the_whole_r0_to_r4_ladder_is_on_the_trace_at_both_eps():
    """r0 at (40,8,2) ε = ½ under the r0 ε = ½ gate (raws 2026-09-06): the
    last of the ten (rung, ε) artifacts. r0 → r1 at ε = ½: Q2[T0] 0.9957,
    Q5joint 0.9016, Q1[L0] 0.7295; reset part 0.5551, corrected
    E[H | U > 0] 3.5200 vs closed form 4.2138."""
    (r0,) = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r0-2026-09-06-eps1_2.json"))["rows"]
    assert r0["eps"] == "1/2" and r0["rung"] == "r0" and r0["n_windows"] == 12739 and r0["gate"].count("-r0-2026-09-06-full-eps1_2-shard") == 8
    assert round(r0["mean_state_entropy_bits"], 4) == 3.3711
    for k, v in (("Q1[L0]", 0.8090), ("Q1[L1]", 0.5279), ("Q2[T0]", 1.0409), ("Q3[D0]", 0.1697), ("Q5joint", 0.9592)):
        assert round(r0["queries"][k]["mean_bits"], 4) == v, k
    r1 = json.load(open(DOCS / "c1prime-loop-query-ceilings-40-8-2-r1-2026-09-05-eps1_2.json"))["rows"][0]
    g = statutory_gaps(r0, r1)
    assert max(g, key=g.get) == "Q2[T0]" and round(max(g.values()), 4) == 0.9957 and all(v >= -1e-12 for v in g.values())
    c = conditional_from_by_endpoint(r0["by_endpoint"], WindowLaw(T_ep=40, L=8, B=2), "mean_state_entropy_bits")
    assert round(c["H_U0"], 4) == 0.5551 and round(c["E_H_given_U_pos"], 4) == 3.5200
    q4 = json.load(open(DOCS / "c1prime-loop-q4-ceilings-40-8-2-r0-W4-2026-09-06-eps1_2.json"))["rows"][0]
    assert (round(q4["total_bits"], 4), round(q4["gap_bits"], 4)) == (1.4366, 0.7161)
    t = json.load(open(DOCS / "c1prime-loop-predictive-targets-40-8-2-r0-2026-09-06-eps1_2.json"))["rows"][0]
    assert t["n_pnext_classes"] == 4651 and round(t["means"]["kinds2"]["gap"], 4) == 0.7973 and t["divergent"]["windows"] == 6614
    # every (rung, eps) artifact of the three producers exists
    for rung, d in (("r0", "06"), ("r1", "05"), ("r2", "05"), ("r3", "06")):
        for tag in ("", "-eps1_2"):
            assert (DOCS / f"c1prime-loop-query-ceilings-40-8-2-{rung}-2026-09-{d}{tag}.json").exists()
            assert (DOCS / f"c1prime-loop-q4-ceilings-40-8-2-{rung}-W4-2026-09-{d}{tag}.json").exists()
            assert (DOCS / f"c1prime-loop-predictive-targets-40-8-2-{rung}-2026-09-{d}{tag}.json").exists()
    assert (DOCS / "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-04.json").exists() and (DOCS / "c1prime-loop-query-ceilings-40-8-2-r4-2026-09-05-eps1_2.json").exists()
