# Supplementary material (anonymised)

`src/` is the instrument: the kernel (`yupi/kernel.py`), interfaces, exact filters and ceilings, and the learner code.
`docs/` holds every committed result file the test suite checks against; `tests/` holds the test suite (`uv run --extra learner pytest -q`). `scripts/` holds the analyses; `results/` holds the summary
result files every number in the paper is computed from, and the notes recording what was declared before each check
ran. `results/paper1m-supplement-provenance-v1.md` maps each section of the paper to its result files.

Exact tables are regenerated, not shipped (they are large): for example
`uv run python scripts/kind_uncertainty_split.py --eps 1 --rows-dir <dir>` rebuilds the per-class rows behind §3.1
and §4 (minutes on a workstation CPU), whose hashes are listed in `results/split-v2-rows-sha256-2026-10-15.txt`;
`scripts/support_audit_table.py` then reproduces the §4.2 table and the §4.3 exact sweep. Trained checkpoints are
not included (about 3 MB each); `scripts/learner_train.py` retrains them.

**Expected test results.** In this anonymised copy, 1,044 tests pass and 5 fail, all in
`tests/test_relay_replication_score.py`: four check the byte-for-byte hash of a frozen result file whose contents
anonymisation necessarily altered (a local path was replaced), and one reads a design note that is not included. In
the original repository all five pass.
