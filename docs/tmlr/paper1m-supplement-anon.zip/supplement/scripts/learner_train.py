"""Train one model on one corpus (trainer spec; plan Task 5).

  uv run --extra learner python scripts/learner_train.py --corpus-dir corpus/<name>/<run-id> --seed 1 \\
      --out ~/.cache/yupi-scratch/runs/<cell>-s1 [--device cpu|cuda] [--epochs 10] [--batch-size 256] \\
      [--max-steps N] [--resume]

Prints the summary JSON. SIGTERM (the lease's kill) checkpoints and exits 0;
rerun with --resume to continue from the checkpoint.
"""
import argparse
import json
import sys

from yupi.learner.model import ModelConfig
from yupi.learner.train import TrainConfig, train


def build_config(a) -> TrainConfig:
    """TrainConfig from parsed arguments; d_mlp = 4 d_model; lr_min defaults to lr / 10."""
    model = ModelConfig(d_model=a.d_model, n_layer=a.n_layer, n_head=a.n_head, d_mlp=4 * a.d_model,
                        arch=getattr(a, "arch", "transformer"))
    lr_min = a.lr / 10 if a.lr_min is None else a.lr_min
    return TrainConfig(corpus_dir=a.corpus_dir, seed=a.seed, out_dir=a.out, device=a.device, batch_size=a.batch_size,
                       epochs=a.epochs, lr=a.lr, lr_min=lr_min, warmup=a.warmup, ckpt_every=a.ckpt_every, val_every=a.val_every,
                       max_steps=a.max_steps, unscored_fields=tuple(getattr(a, "unscored_fields", ())),
                       target_corpus_dir=getattr(a, "target_corpus_dir", None),
                       target_fields=tuple(getattr(a, "target_fields", ())), model=model)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--corpus-dir", required=True)
    ap.add_argument("--seed", type=int, required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--batch-size", type=int, default=256)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--lr-min", type=float, default=None, help="cosine floor; default lr / 10 (the recipe's 1e-3 -> 1e-4)")
    ap.add_argument("--warmup", type=int, default=500)
    ap.add_argument("--ckpt-every", type=int, default=500)
    ap.add_argument("--val-every", type=int, default=250)
    ap.add_argument("--max-steps", type=int, default=None)
    ap.add_argument("--d-model", type=int, default=128)
    ap.add_argument("--n-layer", type=int, default=4)
    ap.add_argument("--n-head", type=int, default=4)
    ap.add_argument("--unscored-fields", nargs="*", default=[], help="record fields left out of the loss, e.g. OBJECT")
    ap.add_argument("--arch", default="transformer", choices=["transformer", "gru"])
    ap.add_argument("--target-corpus-dir", default=None, help="targets from this paired corpus (inputs stay from --corpus-dir)")
    ap.add_argument("--target-fields", nargs="*", default=[], help="the only fields at which paired targets may differ")
    ap.add_argument("--resume", action="store_true")
    a = ap.parse_args(argv)
    cfg = build_config(a)
    print(json.dumps(train(cfg, resume=a.resume), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
